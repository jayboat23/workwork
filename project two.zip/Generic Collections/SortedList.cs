﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Generic_Collections
{
    class SortedList
    {
        public void Sortmeplease()
        {

            Console.WriteLine("_____________StartofSortedList________________");
            Console.Write('\n');

            SortedList<string, int> ages = new SortedList<string, int>();


            ages.Add("Joseph", 31);
            ages.Add("Keyna", 23);
            ages.Add("Brittney", 30);
            ages.Add("Zya", 18);
            ages.Add("Thomas", 34);

            Console.WriteLine("The SortedList contains the following people with their ages:");

            foreach(KeyValuePair<string,int> element in ages)
            {
                string name = element.Key;
                int age = element.Value;
                Console.WriteLine($"Name: {name}, Age: {age}");
            }


            Console.WriteLine("_____________EndofSortedList________________");
            Console.Write('\n');
        }
    }
}
