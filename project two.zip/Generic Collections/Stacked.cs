﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Generic_Collections
{
    class Stacked
    {
        public void Stacky()
        {
            Console.WriteLine("_____________StartofStackedList________________");
            Console.Write('\n');
            Stack<int> numbers = new Stack<int>();
            Console.WriteLine("Pushing items onto the stack:");
            foreach (int number in new int[4] { 8, 5, 9, 2 })
            {
                numbers.Push(number); Console.WriteLine($"{number} has been pushed on the stack");
            }
            Console.WriteLine("\nThe stack now contains:");
            foreach (int number in numbers)
            {
                Console.WriteLine(number);
            }
            Console.WriteLine("\nPopping items from the stack:"); while (numbers.Count > 0)
            {
                int number = numbers.Pop(); Console.WriteLine($"{number} has been popped off the stack");
            }
            Console.WriteLine("_____________EndofStackedList________________");
            Console.Write('\n');
        }
    }
}
