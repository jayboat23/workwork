﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Generic_Collections
{
    class HashSet
    {
     
        public void HashIt()

        {

            Console.WriteLine("_____________StartofHashList________________");
            Console.Write('\n');
            HashSet<string> employees = new HashSet<string>(new string[] { "Joseph", "David", "Tommy", "Philip" });
            HashSet<string> customers = new HashSet<string>(new string[] { "Jerry", "Becky", "Harry", "Reggie" });

            employees.Add("Fredrick");
            customers.Add("Tommy");

            Console.WriteLine("Employees:");
            foreach (string name in employees)
            {
                Console.WriteLine(name);
            }

            Console.WriteLine("");
            Console.WriteLine("Customer:");
            foreach(string name in customers)
            {
                Console.WriteLine(name);
            }

            Console.WriteLine("\nCustomer who are also employee:");
            customers.IntersectWith(employees);
            foreach (string name in customers)
            {
                Console.WriteLine(name);
            }

            Console.WriteLine("_____________EndofHashList________________");
            Console.Write('\n');

        }
    }
}
