﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Generic_Collections
{
    class LinkedList
    {
        public void Linked()
        {
            Console.WriteLine("_____________StartofLinkedList________________");
            Console.Write('\n');
            LinkedList<int> numbers = new LinkedList<int>();

            foreach (int number in new int[] { 10,12,14,16,18 })
            {
                numbers.AddFirst(number);
            }
            Console.WriteLine("Iterating using a for statement:\n");

            for (LinkedListNode<int> node = numbers.First; node != null; node = node.Next)
            {
                int number = node.Value; Console.WriteLine(number);
            }
            Console.WriteLine("\nIterating using a foreach statement:\n");
            foreach (int number in numbers)
            {
                Console.WriteLine(number);
            }
            Console.WriteLine("\nIterating list in reverse order:\n");
            for (LinkedListNode<int> node = numbers.Last; node != null; node = node.Previous)
            {
                int number = node.Value; Console.WriteLine(number);
            }
            Console.WriteLine("_____________EndofLinkedList________________");
            Console.Write('\n');
        }
        
    }
}
