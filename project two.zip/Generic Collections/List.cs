﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Generic_Collections
{
     class List
    {
        public void PrintList()
        {
            Console.WriteLine("_____________StartofList<T>________________");
            Console.Write('\n');
            List<int> numbers = new List<int>();
            foreach (int number in new int[5] { 10, 20, 30, 40, 50 })
            {
                numbers.Add(number);
            }

            for (int i = 0; i < numbers.Count; i++)
            {
                int number = numbers[i]; // Note the use of array syntax Console.WriteLine(number);
            }
            foreach (int number in numbers)
            {
                Console.WriteLine(number);
            }
            Console.WriteLine("_____________EndofList<T>________________");
            Console.Write('\n');
        }
    }
}
