﻿using System;
using System.Collections.Generic;


namespace Generic_Collections
{
    class Program
    {
        static void Main(string[] args)
        {

            List l = new List();
            l.PrintList();
            ////_________________
            LinkedList A = new LinkedList();
            A.Linked();

            ///________
            Queue C = new Queue();
            C.BarBQue();
            ///________
            Stacked D = new Stacked();
            D.Stacky();

            ///______
            Dictionary E = new Dictionary();
            E.Diction();
            ///______
            SortedList F = new SortedList();
            F.Sortmeplease();

            HashSet G = new HashSet();
            G.HashIt();

        }
        
    }
}
