﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Generic_Collections
{
    class Queue
    {
        public void BarBQue()
        {
            Console.WriteLine("_____________StartofQueueList________________");
            Console.Write('\n');
            Queue<int> numbers = new Queue<int>();
            Console.WriteLine("Populating the queue:");
            foreach (int number in new int[4] { 10,15,20,25 })
            {
                numbers.Enqueue(number); Console.WriteLine($"{number} has joined the queue");
            }
            Console.WriteLine("\nThe queue contains the following items:");
            foreach (int number in numbers)
            {
                Console.WriteLine(number);
            }
            Console.WriteLine("\nDraining the queue:");
            while (numbers.Count > 0)
            {
                int number = numbers.Dequeue(); Console.WriteLine($"{number} has left the queue");
            }
            Console.WriteLine("_____________EndofQueueList________________");
            Console.Write('\n');
        }
    }
}
