﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Generic_Collections
{
    class Dictionary
    {
        public void Diction()
        {
            Console.WriteLine("_____________StartofDictionaryList________________");
            Console.Write('\n');

            Dictionary<string, int> ages = new Dictionary<string, int>();

            ages.Add("Joseph", 31);
            ages.Add("Keyna", 23);
            ages.Add("Brittney", 30);
            ages.Add("Zya", 18 );
            ages.Add("Thomas", 34);

            Console.WriteLine("They Dictionary contains:");

            foreach(KeyValuePair<string, int> elements in ages)
            {
                string name = elements.Key;
                int age = elements.Value;
                Console.WriteLine($"Name: {name}, Age: {age}");
            }

            Console.WriteLine("_____________EndofDictionaryList________________");
            Console.Write('\n');

        }
    }
}
