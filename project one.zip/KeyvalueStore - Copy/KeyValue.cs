﻿using System;
using System.Collections.Generic;
using System.Text;

namespace KeyvalueStore
{
    // Create a struct named 'keyvalue' which contains one 'string' "key" and one 
    // 'object' "value" as ' public readonly intstance fields'

    public struct keyvalue<T>
    {
     
        public readonly string key;
        public readonly T value;
        // Implement a constructor for `KeyValue` which sets the instance fields

        public keyvalue(string a, T b)
        {
            key = a;
            value = b;
        }

    }
}
