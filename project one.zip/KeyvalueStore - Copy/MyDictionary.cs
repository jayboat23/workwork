﻿using System;
using System.Collections.Generic;
using System.Text;

namespace KeyvalueStore
{
    //Create a class named `MyDictionary` which contains one array of KeyValue structs and
    //one `int` to keep track of the number of stored values as private instance fields. 
    //You may choose a reasonable fixed size for the array. 
    class MyDictionary<T>
    {
      
        private keyvalue<T>[] values = new keyvalue<T>[10];
        private int numvalues = 0;

        //Implement an indexer which takes a string (key) and returns an object (value).

        public T this[ string key]
        {
            // The `get` property should search the array for the given key and return the associated value if it exists.If the key does not exist, 
            //the property should throw a KeyNotFoundException.

            get
            {
                for(int i = 0; i < numvalues; i++)
                {
                    if (values[i].key == key)
                        return values[i].value;
                }
                throw new KeyNotFoundException();
            }

            //The `set` property should search the array for the given key and replace the KeyValue with a `new KeyValue(...)`
            //if it exists.If the key does not exist, it should be added as a `new KeyValue(...)`.

            set
            {
                for (int i = 0;  i < numvalues; i++)
                {
                    if(values[i].key==key)
                    {
                        values[i] = new keyvalue<T>(key, value);
                            return;

                    }
                }
                values[numvalues++] = new keyvalue<T>(key, value);

            }

        }



            


    }
}

